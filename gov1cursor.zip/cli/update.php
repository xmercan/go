#!/usr/bin/env php
<?php

/**
 * GO! V1 — Update / Migration CLI Aracı
 *
 * Kullanım:
 *   php cli/update.php --version=1.0.1
 *   php cli/update.php --check
 *   php cli/update.php --list
 */

declare(strict_types=1);

define('GO_ROOT',  dirname(__DIR__));
define('GO_START', microtime(true));

if (php_sapi_name() !== 'cli') {
    http_response_code(403);
    die("Bu araç yalnızca CLI üzerinden çalıştırılabilir.\n");
}

require GO_ROOT . '/core/Env.php';
\GO\Core\Env::load(GO_ROOT . '/.env');

$options = getopt('', ['version:', 'check', 'list', 'help']);

if (isset($options['help']) || empty($options)) {
    echo "GO! V1 — Update CLI\n";
    echo "Kullanım:\n";
    echo "  php cli/update.php --check          Mevcut versiyonu kontrol et\n";
    echo "  php cli/update.php --list           Uygulanmış migration'ları listele\n";
    echo "  php cli/update.php --version=1.0.1  Belirli versiyona güncelle\n\n";
    exit(0);
}

// DB bağlantısı
require GO_ROOT . '/config.php';
require GO_ROOT . '/core/Database.php';

try {
    $pdo = \GO\Core\Database::getInstance();
} catch (\Throwable $e) {
    die("DB bağlantı hatası: " . $e->getMessage() . "\n");
}

// --- --check ---
if (isset($options['check'])) {
    $row = $pdo->query("SELECT setting_value FROM settings WHERE setting_key = 'app_version'")->fetch(\PDO::FETCH_ASSOC);
    echo "Mevcut versiyon: " . ($row['setting_value'] ?? 'bilinmiyor') . "\n";
    exit(0);
}

// --- --list ---
if (isset($options['list'])) {
    $rows = $pdo->query("SELECT version, applied_at FROM schema_migrations ORDER BY applied_at ASC")->fetchAll(\PDO::FETCH_ASSOC);
    echo "Uygulanmış migration'lar:\n";
    foreach ($rows as $r) {
        echo "  [{$r['applied_at']}] v{$r['version']}\n";
    }
    exit(0);
}

// --- --version ---
if (isset($options['version'])) {
    $version    = $options['version'];
    $migrations = GO_ROOT . '/database/migrations';

    if (!is_dir($migrations)) {
        echo "Migration klasörü bulunamadı: {$migrations}\n";
        exit(1);
    }

    $files = glob($migrations . '/' . $version . '*.sql');
    if (empty($files)) {
        echo "v{$version} için migration dosyası bulunamadı.\n";
        exit(1);
    }

    // Zaten uygulanmış mı?
    $applied = $pdo->prepare("SELECT id FROM schema_migrations WHERE version = ?");
    $applied->execute([$version]);
    if ($applied->fetch()) {
        echo "v{$version} zaten uygulanmış.\n";
        exit(0);
    }

    foreach ($files as $file) {
        echo "Çalıştırılıyor: " . basename($file) . "\n";
        $sql = file_get_contents($file);
        $statements = array_filter(array_map('trim', explode(';', $sql)));

        $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");
        $errors = [];
        foreach ($statements as $stmt) {
            if (empty($stmt) || str_starts_with(ltrim($stmt), '--')) continue;
            try {
                $pdo->exec($stmt);
            } catch (\PDOException $e) {
                $errors[] = $e->getMessage();
            }
        }
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");

        if (!empty($errors)) {
            echo "UYARI — bazı statement'lar başarısız:\n";
            foreach ($errors as $err) echo "  - {$err}\n";
        } else {
            echo "  ✓ Başarılı\n";
        }
    }

    // Kaydet
    $pdo->prepare("INSERT IGNORE INTO schema_migrations (version, applied_at) VALUES (?, NOW())")->execute([$version]);
    $pdo->prepare("UPDATE settings SET setting_value = ? WHERE setting_key = 'app_version'")->execute([$version]);

    echo "\nv{$version} uygulandı. ✓\n";
    echo "Süre: " . round((microtime(true) - GO_START) * 1000) . "ms\n";
    exit(0);
}

echo "Geçersiz komut. --help için yardım.\n";
exit(1);
