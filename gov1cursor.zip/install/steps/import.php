<?php

/**
 * Adım 3: SQL İçe Aktarma
 */

$error   = '';
$results = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sqlFile = GO_ROOT . '/database/GoV1.sql';

    if (!file_exists($sqlFile)) {
        $error = 'GoV1.sql dosyası bulunamadı: ' . $sqlFile;
    } else {
        try {
            $host = $_SESSION['db_host'] ?? 'localhost';
            $port = (int)($_SESSION['db_port'] ?? 3306);
            $name = $_SESSION['db_name'] ?? '';
            $user = $_SESSION['db_user'] ?? '';
            $pass = $_SESSION['db_pass'] ?? '';

            $dsn = "mysql:host={$host};port={$port};dbname={$name};charset=utf8mb4";
            $pdo = new PDO($dsn, $user, $pass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
            $pdo->exec("SET NAMES utf8mb4");
            $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");

            $sql = file_get_contents($sqlFile);

            // SQL'i ifadelere böl (basit splitter)
            $statements = array_filter(
                array_map('trim', explode(';', $sql)),
                fn($s) => $s !== '' && !str_starts_with(ltrim($s), '--')
            );

            $executed = 0;
            $errors   = [];

            foreach ($statements as $stmt) {
                $stmt = trim($stmt);
                if (empty($stmt) || str_starts_with($stmt, '--')) continue;
                try {
                    $pdo->exec($stmt);
                    $executed++;
                } catch (PDOException $e) {
                    $msg = $e->getMessage();
                    // Duplicate entry / already exists uyarı olarak say
                    if (str_contains($msg, 'Duplicate entry') || str_contains($msg, 'already exists')) {
                        $results[] = ['type' => 'warn', 'msg' => 'Uyarı (atlandı): ' . substr($msg, 0, 100)];
                    } else {
                        $errors[] = $msg;
                    }
                }
            }

            $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");

            if (empty($errors)) {
                $results[] = ['type' => 'ok', 'msg' => "{$executed} SQL ifadesi başarıyla çalıştırıldı."];
                $_SESSION['install_completed'][] = 3;
                $_SESSION['db_imported']         = true;
                header('Location: /install/?step=4');
                exit;
            } else {
                $error = 'SQL hataları: ' . implode(' | ', array_slice($errors, 0, 3));
            }
        } catch (PDOException $e) {
            $error = 'Veritabanı bağlantısı kurulamadı: ' . $e->getMessage();
        }
    }
}

install_head('SQL İçe Aktarma', $step, $stepTitles);
?>

<div class="alert alert-info">
    <strong>GoV1.sql</strong> dosyasındaki tüm tablolar ve başlangıç verileri veritabanınıza yüklenecek.
    Mevcut veriler üzerine yazılabilir — temiz bir veritabanı kullanmanız önerilir.
</div>

<?php if ($error): ?>
<div class="alert alert-error"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
<?php endif; ?>

<?php foreach ($results as $r): ?>
<div class="alert alert-<?= $r['type'] === 'ok' ? 'success' : 'info' ?>">
    <?= htmlspecialchars($r['msg'], ENT_QUOTES, 'UTF-8') ?>
</div>
<?php endforeach; ?>

<p style="color:rgba(255,255,255,.6);font-size:.9rem;margin-bottom:1.5rem">
    Veritabanı: <strong><?= htmlspecialchars($_SESSION['db_name'] ?? '', ENT_QUOTES, 'UTF-8') ?></strong> /
    Sunucu: <strong><?= htmlspecialchars($_SESSION['db_host'] ?? '', ENT_QUOTES, 'UTF-8') ?></strong>
</p>

<form method="POST">
    <button type="submit" class="btn btn-primary btn-full">SQL Yükle ve Devam Et →</button>
</form>

<?php
install_foot();
